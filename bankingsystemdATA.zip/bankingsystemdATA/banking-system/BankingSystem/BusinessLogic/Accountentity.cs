﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using database;
using Entities;

namespace BusinessLogic
{
   public class Accountentity
    {

        public Accountentity()
        {
        }
        public void Insert()
        {
            Console.WriteLine("hello");
            int id = Int32.Parse(Console.ReadLine());
            int branch = Int32.Parse(Console.ReadLine());
            string accholder = Console.ReadLine();
            int bal = Int32.Parse(Console.ReadLine());

            Accounte a= new Accounte();
            a.Insert(id, accholder,branch,bal);



        }
        public void Withdraw()
        {
            int id = Int32.Parse(Console.ReadLine());
            int balance = Int32.Parse(Console.ReadLine());
            Accounte a = new Accounte();
            a.Update(id,balance);
        }
        public void Search()
        {
         
            Accounte a = new Accounte();
            int id = Int32.Parse(Console.ReadLine());
            int pos=a.SearchData(id);
            Console.WriteLine("{0)",pos);

        }
        public void Display()
        {
            int id = Int32.Parse(Console.ReadLine());
            Accounte a = new Accounte();
            Accounts acc =a.DisplayData(id);
            Console.WriteLine("Account id is {0} \n Holder is{1} \n Account branch is {2} \n  balance amount is {3}", acc._accountId, acc._accountHolder, acc._accountBranch, acc._balanceAmount);
        }
    }
}
